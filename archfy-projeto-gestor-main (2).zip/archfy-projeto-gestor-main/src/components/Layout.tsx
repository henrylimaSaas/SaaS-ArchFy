
import React from 'react';
import Sidebar from './Sidebar';

interface LayoutProps {
  children: React.ReactNode;
  showSidebar?: boolean;
}

export const Layout: React.FC<LayoutProps> = ({ children, showSidebar = true }) => {
  if (!showSidebar) {
    return (
      <div className="min-h-screen bg-secondary">
        <main className="w-full">
          {children}
        </main>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-secondary">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <main className="w-full">
          {children}
        </main>
      </div>
    </div>
  );
};

