
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  Home,
  FileText,
  Users,
  Calendar,
  BarChart2,
  Settings,
  LogOut,
  ChevronLeft,
  Menu
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  to: string;
  active: boolean;
  collapsed: boolean;
}

const NavItem = ({ icon, label, to, active, collapsed }: NavItemProps) => {
  return (
    <Link
      to={to}
      className={cn(
        'flex items-center gap-3 px-4 py-3 rounded-md transition-all',
        active 
          ? 'bg-accent/20 text-accent font-medium shadow-sm' 
          : 'text-white/90 hover:bg-white/10 hover:text-white',
        collapsed ? 'justify-center' : ''
      )}
    >
      <div className={cn(
        "transition-all duration-200",
        active ? 'text-accent' : 'text-white/80'
      )}>
        {icon}
      </div>
      {!collapsed && <span className={cn(
        "transition-all",
        active ? 'font-medium' : ''
      )}>{label}</span>}
    </Link>
  );
};

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  
  const navItems = [
    { icon: <Home size={22} />, label: 'Dashboard', path: '/dashboard' },
    { icon: <FileText size={22} />, label: 'Projetos', path: '/projetos' },
    { icon: <Users size={22} />, label: 'Clientes', path: '/clientes' },
    { icon: <Calendar size={22} />, label: 'Agenda', path: '/agenda' },
    { icon: <BarChart2 size={22} />, label: 'Financeiro', path: '/financeiro' },
  ];

  return (
    <div 
      className={cn(
        'h-screen bg-primary flex flex-col transition-all duration-300 sticky top-0 z-50',
        collapsed ? 'w-24' : 'w-80'
      )}
    >
      <div className="py-6 px-6 flex items-center justify-between border-b border-white/10">
        {!collapsed && (
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-white rounded-md flex items-center justify-center shadow-md">
              <span className="text-primary font-bold text-xl">A</span>
            </div>
            <h1 className="text-2xl font-bold text-white">ArchFy</h1>
          </div>
        )}
        {collapsed && (
          <div className="w-12 h-12 bg-white rounded-md flex items-center justify-center mx-auto shadow-md">
            <span className="text-primary font-bold text-xl">A</span>
          </div>
        )}
        <Button 
          variant="ghost" 
          size="icon" 
          className="text-white hover:bg-white/10 shadow-sm"
          onClick={() => setCollapsed(!collapsed)}
        >
          {collapsed ? <Menu size={22} /> : <ChevronLeft size={22} />}
        </Button>
      </div>
      
      <div className="flex-1 py-8 flex flex-col gap-2 px-4 overflow-y-auto">
        {navItems.map((item) => (
          <NavItem
            key={item.path}
            icon={item.icon}
            label={item.label}
            to={item.path}
            active={location.pathname === item.path}
            collapsed={collapsed}
          />
        ))}
      </div>
      
      <div className="mt-auto border-t border-white/10 py-6 px-4">
        <NavItem
          icon={<Settings size={22} />}
          label="Configurações"
          to="/configuracoes"
          active={location.pathname === '/configuracoes'}
          collapsed={collapsed}
        />
        <div className="mt-4">
          <button 
            className={cn(
              'flex items-center gap-3 px-4 py-3 rounded-md transition-all w-full',
              'text-white/90 hover:bg-white/10 hover:text-white',
              collapsed ? 'justify-center' : ''
            )}
            aria-label="Sair do sistema"
          >
            <LogOut size={22} />
            {!collapsed && <span>Sair</span>}
          </button>
        </div>
      </div>
    </div>
  );
}

export default Sidebar;
