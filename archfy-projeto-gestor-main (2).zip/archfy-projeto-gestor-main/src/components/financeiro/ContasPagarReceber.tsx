
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { Area, AreaChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

interface ContasPagarReceberProps {
  periodo: string;
}

const ContasPagarReceber: React.FC<ContasPagarReceberProps> = ({ periodo }) => {
  // Dados de exemplo para os gráficos
  const contasPagarData = [
    { dia: '01', valor: 0 },
    { dia: '03', valor: 0 },
    { dia: '05', valor: 0 },
    { dia: '07', valor: 0 },
    { dia: '09', valor: 0 },
    { dia: '11', valor: 0 },
    { dia: '13', valor: 10000 },
    { dia: '15', valor: 0 },
    { dia: '17', valor: 110000 },
    { dia: '19', valor: 0 },
    { dia: '21', valor: 300000 },
    { dia: '23', valor: 0 },
    { dia: '25', valor: 0 },
    { dia: '27', valor: 90000 },
    { dia: '29', valor: 20000 },
    { dia: '31', valor: 0 },
  ];
  
  const contasReceberData = [
    { dia: '01', valor: 0 },
    { dia: '03', valor: 0 },
    { dia: '05', valor: 0 },
    { dia: '07', valor: 0 },
    { dia: '09', valor: 0 },
    { dia: '11', valor: 0 },
    { dia: '13', valor: 0 },
    { dia: '15', valor: 0 },
    { dia: '17', valor: 0 },
    { dia: '19', valor: 0 },
    { dia: '21', valor: 0 },
    { dia: '23', valor: 0 },
    { dia: '25', valor: 0 },
    { dia: '27', valor: 0 },
    { dia: '29', valor: 0 },
    { dia: '31', valor: 0 },
  ];

  // Configurações para os gráficos
  const chartConfigPagar = {
    valor: {
      label: 'Valor a Pagar',
      theme: {
        light: '#E74C3C',
        dark: '#E95F71',
      },
    }
  };
  
  const chartConfigReceber = {
    valor: {
      label: 'Valor a Receber',
      theme: {
        light: '#89F1B3',
        dark: '#89F1B3',
      },
    }
  };

  // Lista de contas
  const contas = [
    { id: 1, descricao: 'Aluguel do escritório', tipo: 'pagar', valor: 5000.00, vencimento: '15/05/2023', status: 'pendente' },
    { id: 2, descricao: 'Serviços de design - Projeto Residence XYZ', tipo: 'receber', valor: 8500.00, vencimento: '20/05/2023', status: 'pendente' },
    { id: 3, descricao: 'Fornecedor de materiais', tipo: 'pagar', valor: 3240.00, vencimento: '24/05/2023', status: 'pendente' },
    { id: 4, descricao: 'Consultoria técnica', tipo: 'pagar', valor: 1200.00, vencimento: '28/05/2023', status: 'pendente' },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-medium">Contas a pagar e a receber</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="space-y-2 col-span-1">
              <Label htmlFor="data-vencimento">Data de vencimento</Label>
              <Input id="data-vencimento" type="date" defaultValue="2023-05-31" />
            </div>
            <div className="space-y-2 col-span-2 flex items-end">
              <div className="flex space-x-4">
                <div className="text-center px-4 py-2 bg-white rounded-md border">
                  <p className="text-sm text-muted-foreground">A pagar hoje</p>
                  <p className="text-xl font-medium text-destructive">R$ 0,00</p>
                </div>
                <div className="text-center px-4 py-2 bg-white rounded-md border">
                  <p className="text-sm text-muted-foreground">A receber hoje</p>
                  <p className="text-xl font-medium text-accent-foreground">R$ 289.209,01</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="h-48">
              <p className="text-sm font-medium mb-2">Contas a pagar</p>
              <ChartContainer config={chartConfigPagar}>
                <AreaChart data={contasPagarData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorPagar" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#E74C3C" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#E74C3C" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis dataKey="dia" axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area 
                    type="monotone" 
                    dataKey="valor" 
                    stroke="var(--color-valor, #E74C3C)" 
                    strokeWidth={2}
                    fill="url(#colorPagar)" 
                  />
                </AreaChart>
              </ChartContainer>
            </div>

            <div className="h-48">
              <p className="text-sm font-medium mb-2">Contas a receber</p>
              <ChartContainer config={chartConfigReceber}>
                <AreaChart data={contasReceberData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorReceber" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#89F1B3" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#89F1B3" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis dataKey="dia" axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area 
                    type="monotone" 
                    dataKey="valor" 
                    stroke="var(--color-valor, #89F1B3)" 
                    strokeWidth={2}
                    fill="url(#colorReceber)" 
                  />
                </AreaChart>
              </ChartContainer>
            </div>
          </div>

          <div className="mt-4">
            <p className="text-sm font-medium mb-2">Próximas contas</p>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Vencimento</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contas.map((conta) => (
                    <TableRow key={conta.id}>
                      <TableCell>{conta.descricao}</TableCell>
                      <TableCell>
                        <span className={conta.tipo === 'pagar' ? 'text-destructive' : 'text-accent-foreground'}>
                          {conta.tipo === 'pagar' ? 'A pagar' : 'A receber'}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className={conta.tipo === 'pagar' ? 'text-destructive' : 'text-accent-foreground'}>
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(conta.valor)}
                        </span>
                      </TableCell>
                      <TableCell>{conta.vencimento}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">
                          {conta.status}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>

          <div className="text-right text-sm mt-4">
            <p className="text-muted-foreground">Total no período</p>
            <p className="text-lg font-medium">R$ 857.986,51</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ContasPagarReceber;
