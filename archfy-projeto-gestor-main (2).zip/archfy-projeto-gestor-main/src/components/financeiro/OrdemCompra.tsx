
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartLegendContent } from '@/components/ui/chart';
import { PieChart, Pie, Cell, Legend, ResponsiveContainer } from 'recharts';

interface OrdemCompraProps {
  periodo: string;
}

const OrdemCompra: React.FC<OrdemCompraProps> = ({ periodo }) => {
  // Dados para o gráfico de ordens de compra
  const ordemCompraData = [
    { name: 'Em aprovação', value: 36, color: '#3B82F6' },
    { name: 'Enviada ao fornecedor', value: 21, color: '#4B5563' },
    { name: 'Gerada', value: 5, color: '#10B981' },
    { name: 'Não aprovado', value: 16, color: '#F59E0B' },
    { name: 'Parcialmente recebida', value: 22, color: '#6366F1' },
  ];

  const solicitacoesData = [
    { name: 'Aberta', value: 45, color: '#3B82F6' },
    { name: 'Parcial', value: 25, color: '#4B5563' },
    { name: 'Rascunho', value: 6, color: '#10B981' },
  ];

  // Configuração para o gráfico
  const chartConfig = {
    'Em aprovação': { label: 'Em aprovação' },
    'Enviada ao fornecedor': { label: 'Enviada ao fornecedor' },
    'Gerada': { label: 'Gerada' },
    'Não aprovado': { label: 'Não aprovado' },
    'Parcialmente recebida': { label: 'Parcialmente recebida' },
    'Aberta': { label: 'Aberta' },
    'Parcial': { label: 'Parcial' },
    'Rascunho': { label: 'Rascunho' },
  };

  const Bullet = ({ color, size = 8 }: { color: string; size?: number }) => (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: '50%',
        backgroundColor: color,
      }}
    />
  );

  const renderCustomizedLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
    index,
  }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = outerRadius * 1.1;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return percent > 0.05 ? (
      <text
        x={x}
        y={y}
        fill="#333"
        textAnchor={x > cx ? 'start' : 'end'}
        dominantBaseline="central"
        fontSize={12}
        fontWeight={500}
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    ) : null;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-medium">Ordens de compra</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex flex-col items-center">
            <ChartContainer config={chartConfig} className="h-full w-full">
              <PieChart width={300} height={200}>
                <Pie
                  data={ordemCompraData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={renderCustomizedLabel}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {ordemCompraData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ChartContainer>

            <div className="flex flex-wrap justify-center gap-4 mt-4">
              {ordemCompraData.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Bullet color={item.color} />
                  <span className="text-xs">{item.name}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 text-center">
            <p className="text-sm text-muted-foreground">Detalhamento por prioridade</p>
            <div className="flex justify-center gap-4 mt-2">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Alta</p>
                <p className="font-medium text-sm">23</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Média</p>
                <p className="font-medium text-sm">46</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Baixa</p>
                <p className="font-medium text-sm">31</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-medium">Solicitações</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center">
            <div className="text-xl font-bold mb-4">76</div>
            <div className="h-48 w-48">
              <ChartContainer config={chartConfig}>
                <PieChart>
                  <Pie
                    data={solicitacoesData}
                    cx="50%"
                    cy="50%"
                    innerRadius={0}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {solicitacoesData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ChartContainer>
            </div>

            <div className="flex flex-wrap justify-center gap-4 mt-4">
              {solicitacoesData.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Bullet color={item.color} />
                  <span className="text-xs">{item.name}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default OrdemCompra;
