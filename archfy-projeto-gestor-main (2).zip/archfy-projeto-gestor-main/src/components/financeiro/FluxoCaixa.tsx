
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

interface FluxoCaixaProps {
  periodo: string;
}

const FluxoCaixa: React.FC<FluxoCaixaProps> = ({ periodo }) => {
  // Dados de exemplo para o gráfico de fluxo de caixa
  const fluxoCaixaData = [
    { dia: '01/05', recebimentos: 0, pagamentos: 0, saldo: 0 },
    { dia: '02/05', recebimentos: 0, pagamentos: 0, saldo: 0 },
    { dia: '03/05', recebimentos: 0, pagamentos: 0, saldo: 0 },
    { dia: '04/05', recebimentos: 0, pagamentos: 0, saldo: 0 },
    { dia: '05/05', recebimentos: 0, pagamentos: 0, saldo: 0 },
    { dia: '06/05', recebimentos: 0, pagamentos: 0, saldo: 0 },
    { dia: '07/05', recebimentos: 0, pagamentos: 0, saldo: 0 },
    { dia: '08/05', recebimentos: 2800000, pagamentos: 250000, saldo: 2550000 },
    { dia: '09/05', recebimentos: 0, pagamentos: 0, saldo: 2550000 },
    { dia: '10/05', recebimentos: 0, pagamentos: 0, saldo: 2550000 },
    { dia: '11/05', recebimentos: 0, pagamentos: 0, saldo: 2550000 },
    { dia: '12/05', recebimentos: 0, pagamentos: 0, saldo: 2550000 },
    { dia: '13/05', recebimentos: 0, pagamentos: 0, saldo: 2550000 },
    { dia: '14/05', recebimentos: 0, pagamentos: 0, saldo: 2550000 },
    { dia: '15/05', recebimentos: 0, pagamentos: 120000, saldo: 2430000 },
    { dia: '16/05', recebimentos: 0, pagamentos: 0, saldo: 2430000 },
    { dia: '17/05', recebimentos: 1800000, pagamentos: 0, saldo: 4230000 },
    { dia: '18/05', recebimentos: 0, pagamentos: 0, saldo: 4230000 },
    { dia: '19/05', recebimentos: 0, pagamentos: 0, saldo: 4230000 },
    { dia: '20/05', recebimentos: 0, pagamentos: 0, saldo: 4230000 },
    { dia: '21/05', recebimentos: 0, pagamentos: 0, saldo: 4230000 },
    { dia: '22/05', recebimentos: 0, pagamentos: 0, saldo: 4230000 },
    { dia: '23/05', recebimentos: 0, pagamentos: 0, saldo: 4230000 },
    { dia: '24/05', recebimentos: 0, pagamentos: 0, saldo: 4230000 },
    { dia: '25/05', recebimentos: 0, pagamentos: 0, saldo: 4230000 },
  ];

  // Configurações para o gráfico
  const chartConfig = {
    saldo: {
      label: 'Saldo',
      theme: {
        light: '#1F3B73',
        dark: '#4C6EF5',
      },
    },
    recebimentos: {
      label: 'Recebimentos',
      theme: {
        light: '#89F1B3',
        dark: '#89F1B3',
      },
    },
    pagamentos: {
      label: 'Pagamentos',
      theme: {
        light: '#E74C3C',
        dark: '#E95F71',
      },
    },
  };

  // Formatador para valores em reais
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 2,
    }).format(value / 100);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-medium">Fluxo de caixa diário</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="space-y-2">
              <Label htmlFor="data-inicio">De</Label>
              <Input id="data-inicio" type="date" defaultValue="2023-05-01" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="data-fim">até</Label>
              <Input id="data-fim" type="date" defaultValue="2023-05-31" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="conta">Conta</Label>
              <select id="conta" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm">
                <option value="">Selecione...</option>
                <option value="principal">Principal</option>
                <option value="investimentos">Investimentos</option>
              </select>
            </div>
          </div>

          <div className="h-72">
            <ChartContainer config={chartConfig}>
              <AreaChart data={fluxoCaixaData} margin={{ top: 10, right: 30, left: 30, bottom: 20 }}>
                <defs>
                  <linearGradient id="colorSaldo" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#1F3B73" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#1F3B73" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="dia" axisLine={false} tickLine={false} />
                <YAxis 
                  tickFormatter={(value) => `${Math.round(value / 1000000)}M`} 
                  axisLine={false} 
                  tickLine={false}
                />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Area 
                  type="monotone" 
                  dataKey="saldo" 
                  stackId="1"
                  stroke="var(--color-saldo, #1F3B73)"
                  strokeWidth={2} 
                  fill="url(#colorSaldo)"
                />
                <Bar dataKey="recebimentos" fill="var(--color-recebimentos, #89F1B3)" barSize={20} />
                <Bar dataKey="pagamentos" fill="var(--color-pagamentos, #E74C3C)" barSize={20} />
              </AreaChart>
            </ChartContainer>
          </div>

          <div className="grid grid-cols-3 gap-4 mt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Recebimentos no período</p>
              <p className="text-lg font-medium mt-1 text-accent-foreground">R$ 4.600.000,00</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Pagamentos no período</p>
              <p className="text-lg font-medium mt-1 text-destructive">R$ 370.000,00</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Saldo atual</p>
              <p className="text-xl font-medium mt-1">R$ 4.230.000,00</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FluxoCaixa;
