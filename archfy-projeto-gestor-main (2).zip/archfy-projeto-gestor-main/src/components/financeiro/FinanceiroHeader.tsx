
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { BarChart2 } from 'lucide-react';
import { MetricCard } from '@/components/MetricCard';

const FinanceiroHeader = () => {
  return (
    <div className="bg-white p-6 border-b">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-semibold text-gray-900">Financeiro</h1>
        <p className="text-muted-foreground">
          Gerencie as finanças do seu escritório, acompanhe pagamentos e analise o fluxo de caixa
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
          <MetricCard
            title="Saldo Total"
            value="R$ 287.450,15"
            icon={BarChart2}
            trend={{ value: 12.5, isPositive: true }}
          />
          <MetricCard
            title="A Receber (Hoje)"
            value="R$ 0,00"
            icon={BarChart2}
            variant="accent"
          />
          <MetricCard
            title="A Pagar (Hoje)"
            value="R$ 3.240,00"
            icon={BarChart2}
            variant="muted"
          />
          <MetricCard
            title="Comissões Pendentes"
            value="R$ 24.500,00"
            icon={BarChart2}
          />
        </div>
      </div>
    </div>
  );
};

export default FinanceiroHeader;
