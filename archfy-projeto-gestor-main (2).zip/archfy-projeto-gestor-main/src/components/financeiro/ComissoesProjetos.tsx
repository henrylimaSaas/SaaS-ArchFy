import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { ChevronDown, Download, Filter, Plus } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';

const comissaoSchema = z.object({
  projeto: z.string().min(1, 'Nome do projeto é obrigatório'),
  cliente: z.string().min(1, 'Nome do cliente é obrigatório'),
  valor: z.number().min(0.01, 'Valor deve ser maior que zero'),
  data: z.string().min(1, 'Data é obrigatória')
});

type ComissaoFormData = z.infer<typeof comissaoSchema>;

interface ComissoesProjetosProps {
  periodo: string;
}

const ComissoesProjetos: React.FC<ComissoesProjetosProps> = ({ periodo }) => {
  const [open, setOpen] = React.useState(false);
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ComissaoFormData>({
    resolver: zodResolver(comissaoSchema)
  });

  const comissoes = [
    { 
      id: 1, 
      projeto: 'Residência Jardins', 
      cliente: 'Ana Silva', 
      valorProjeto: 245000.00, 
      comissao: 24500.00, 
      dataPrevista: '15/06/2023',
      status: 'pendente'
    },
    { 
      id: 2, 
      projeto: 'Escritório Central Park', 
      cliente: 'Empresa XYZ Ltda', 
      valorProjeto: 380000.00, 
      comissao: 38000.00, 
      dataPrevista: '22/05/2023',
      status: 'recebido'
    },
    { 
      id: 3, 
      projeto: 'Loft Vila Madalena', 
      cliente: 'Roberto Gomes', 
      valorProjeto: 175000.00, 
      comissao: 17500.00, 
      dataPrevista: '08/07/2023',
      status: 'pendente'
    },
    { 
      id: 4, 
      projeto: 'Casa de Praia', 
      cliente: 'Família Martins', 
      valorProjeto: 320000.00, 
      comissao: 32000.00, 
      dataPrevista: '10/05/2023',
      status: 'atrasado'
    },
  ];

  const handleNovaComissao = (data: ComissaoFormData) => {
    toast.success('Comissão registrada com sucesso!');
    setOpen(false);
    reset();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-medium">Comissões de Projetos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-6">
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Input className="max-w-xs" placeholder="Buscar projeto ou cliente" />
              <Button size="icon" variant="outline">
                <Filter size={18} />
              </Button>
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <Button variant="secondary">
                <Download size={16} className="mr-1" />
                Exportar
              </Button>
              <Dialog open={open} onOpenChange={setOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus size={16} className="mr-1" />
                    Nova Comissão
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Registrar Nova Comissão</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSubmit(handleNovaComissao)} className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label htmlFor="projeto">Projeto</Label>
                      <Input 
                        id="projeto" 
                        placeholder="Nome do projeto" 
                        {...register('projeto')}
                        className={errors.projeto ? 'border-red-500' : ''}
                      />
                      {errors.projeto && (
                        <p className="text-xs text-red-500">{errors.projeto.message}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cliente">Cliente</Label>
                      <Input 
                        id="cliente" 
                        placeholder="Nome do cliente" 
                        {...register('cliente')}
                        className={errors.cliente ? 'border-red-500' : ''}
                      />
                      {errors.cliente && (
                        <p className="text-xs text-red-500">{errors.cliente.message}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="valor">Valor do Projeto</Label>
                      <Input 
                        id="valor" 
                        type="number" 
                        placeholder="0.00" 
                        min="0" 
                        step="0.01" 
                        {...register('valor', { valueAsNumber: true })}
                        className={errors.valor ? 'border-red-500' : ''}
                      />
                      {errors.valor && (
                        <p className="text-xs text-red-500">{errors.valor.message}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="data">Data Prevista</Label>
                      <Input 
                        id="data" 
                        type="date" 
                        {...register('data')}
                        className={errors.data ? 'border-red-500' : ''}
                      />
                      {errors.data && (
                        <p className="text-xs text-red-500">{errors.data.message}</p>
                      )}
                    </div>
                    <Button type="submit" className="w-full">
                      Registrar Comissão
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
          
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[250px]">Projeto</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Valor do Projeto</TableHead>
                  <TableHead>Comissão (10%)</TableHead>
                  <TableHead>Data Prevista</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {comissoes.map((comissao) => (
                  <TableRow key={comissao.id}>
                    <TableCell className="font-medium">{comissao.projeto}</TableCell>
                    <TableCell>{comissao.cliente}</TableCell>
                    <TableCell>
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(comissao.valorProjeto)}
                    </TableCell>
                    <TableCell>
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(comissao.comissao)}
                    </TableCell>
                    <TableCell>{comissao.dataPrevista}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        comissao.status === 'recebido' 
                          ? 'bg-green-100 text-green-800'
                          : comissao.status === 'pendente'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                      }`}>
                        {comissao.status === 'recebido' ? 'Recebido' : comissao.status === 'pendente' ? 'Pendente' : 'Atrasado'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon">
                        <ChevronDown size={16} />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          <div className="flex justify-between items-center mt-6">
            <div className="text-sm text-muted-foreground">
              Exibindo {comissoes.length} de {comissoes.length} comissões
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Total em comissões</p>
              <p className="text-lg font-medium">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(
                  comissoes.reduce((total, comissao) => total + comissao.comissao, 0)
                )}
              </p>
              <p className="text-sm text-muted-foreground">
                Pendentes: {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(
                  comissoes
                    .filter(comissao => comissao.status === 'pendente')
                    .reduce((total, comissao) => total + comissao.comissao, 0)
                )}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ComissoesProjetos;