
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface Event {
  id: string;
  title: string;
  type: 'reunião' | 'entrega' | 'visita' | 'pagamento';
  time: string;
  day: 'seg' | 'ter' | 'qua' | 'qui' | 'sex';
}

interface TimelineWeekProps {
  className?: string;
}

const events: Event[] = [
  {
    id: '1',
    title: 'Reunião com cliente',
    type: 'reunião',
    time: '10:00',
    day: 'seg'
  },
  {
    id: '2',
    title: 'Entrega de planta baixa',
    type: 'entrega',
    time: '15:30',
    day: 'ter'
  },
  {
    id: '3',
    title: 'Visita à obra',
    type: 'visita',
    time: '09:00',
    day: 'qua'
  },
  {
    id: '4',
    title: 'Reunião interna',
    type: 'reunião',
    time: '11:00',
    day: 'qua'
  },
  {
    id: '5',
    title: 'Recebimento',
    type: 'pagamento',
    time: '14:00',
    day: 'qui'
  },
  {
    id: '6',
    title: 'Entrega de 3D',
    type: 'entrega',
    time: '16:00',
    day: 'sex'
  }
];

const daysOfWeek = [
  { key: 'seg', label: 'Seg' },
  { key: 'ter', label: 'Ter' },
  { key: 'qua', label: 'Qua' },
  { key: 'qui', label: 'Qui' },
  { key: 'sex', label: 'Sex' }
];

const getEventColor = (type: Event['type']) => {
  switch (type) {
    case 'reunião':
      return 'border-blue-300 bg-blue-50';
    case 'entrega':
      return 'border-green-300 bg-green-50';
    case 'visita':
      return 'border-purple-300 bg-purple-50';
    case 'pagamento':
      return 'border-amber-300 bg-amber-50';
    default:
      return 'border-gray-300 bg-gray-50';
  }
};

export function TimelineWeek({ className }: TimelineWeekProps) {
  return (
    <Card className={className}>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">Linha do Tempo da Semana</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-5 gap-2">
          {daysOfWeek.map((day) => {
            const dayEvents = events.filter(event => event.day === day.key);
            const isToday = day.key === 'qua'; // Simulando que hoje é quarta-feira
            
            return (
              <div key={day.key} className="flex flex-col gap-2">
                <div className={cn(
                  'text-center py-1 rounded-md text-sm font-medium',
                  isToday ? 'bg-primary text-white' : 'bg-gray-100 text-gray-700'
                )}>
                  {day.label}
                </div>
                
                {dayEvents.length > 0 ? (
                  <div className="flex flex-col gap-2">
                    {dayEvents.map(event => (
                      <div 
                        key={event.id}
                        className={cn(
                          'p-2 rounded-md border text-xs',
                          getEventColor(event.type)
                        )}
                      >
                        <div className="font-medium truncate">{event.title}</div>
                        <div className="text-gray-500 mt-1">{event.time}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="h-20 border border-dashed border-gray-200 rounded-md flex items-center justify-center">
                    <span className="text-xs text-gray-400">Sem eventos</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

export default TimelineWeek;
