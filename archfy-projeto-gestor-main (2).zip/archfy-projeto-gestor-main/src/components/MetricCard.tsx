
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  variant?: 'default' | 'accent' | 'muted';
  className?: string;
}

export const MetricCard = ({
  title,
  value,
  icon: Icon,
  trend,
  variant = 'default',
  className,
}: MetricCardProps) => {
  const variantClasses = {
    default: 'bg-white',
    accent: 'bg-accent/10',
    muted: 'bg-secondary',
  };

  const iconColors = {
    default: 'text-primary bg-primary/10',
    accent: 'text-accent bg-accent/20',
    muted: 'text-gray-500 bg-gray-100',
  };

  return (
    <Card className={cn(
      'border overflow-hidden', 
      variantClasses[variant],
      className
    )}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500 mb-1">{title}</p>
            <div className="flex items-end gap-2">
              <p className="metric-value text-gray-900">{value}</p>
              {trend && (
                <span className={cn(
                  'text-xs flex items-center',
                  trend.isPositive ? 'text-green-600' : 'text-red-600'
                )}>
                  {trend.isPositive ? '↑' : '↓'} {Math.abs(trend.value)}%
                </span>
              )}
            </div>
          </div>
          <div className={cn(
            'p-2 rounded-md',
            iconColors[variant]
          )}>
            <Icon size={20} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default MetricCard;
