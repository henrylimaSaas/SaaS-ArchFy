
import React from 'react';
import { Sidebar } from '@/components/Sidebar';
import MetricCard from '@/components/MetricCard';
import ProjectDistributionChart from '@/components/ProjectDistributionChart';
import TimelineWeek from '@/components/TimelineWeek';
import { FileText, Users, Calendar, ChevronRight, Clock, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

const Dashboard = () => {
  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="flex-1 overflow-y-auto bg-secondary">
        {/* Header */}
        <header className="bg-white border-b sticky top-0 z-10">
          <div className="container mx-auto px-6 py-4 flex justify-between items-center">
            <h1 className="text-2xl font-semibold">Dashboard</h1>
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                  <span className="text-xs font-medium text-gray-600">12</span>
                </div>
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-white"></div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-white font-medium">MA</span>
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-medium">Maria Arquiteta</p>
                  <p className="text-xs text-gray-500">Administrador</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="container mx-auto px-6 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <MetricCard
              title="Projetos Ativos"
              value="12"
              icon={FileText}
              trend={{ value: 8, isPositive: true }}
            />
            <MetricCard
              title="Clientes"
              value="24"
              icon={Users}
              variant="accent"
            />
            <MetricCard
              title="Reuniões Agendadas"
              value="5"
              icon={Calendar}
              trend={{ value: 2, isPositive: false }}
            />
            <MetricCard
              title="Entregas do Mês"
              value="8"
              icon={Clock}
              variant="muted"
              trend={{ value: 12, isPositive: true }}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <ProjectDistributionChart className="lg:col-span-1" />
            <TimelineWeek className="lg:col-span-2" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Precisa de Atenção */}
            <Card className="lg:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <AlertCircle size={18} className="text-destructive" />
                  Precisa de Atenção
                </CardTitle>
                <Button variant="ghost" size="sm" className="h-8 text-xs">
                  Ver todos
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y">
                  {[
                    { title: 'Aprovação de orçamento pendente', project: 'Casa Silva', days: 3 },
                    { title: 'Entrega de projeto atrasada', project: 'Escritório Central', days: 5 },
                    { title: 'Pagamento em atraso', project: 'Apartamento 201', days: 7 },
                    { title: 'Revisão de planta solicitada', project: 'Loja Comercial', days: 1 },
                  ].map((item, index) => (
                    <div key={index} className="px-6 py-3 hover:bg-gray-50">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-sm font-medium">{item.title}</p>
                          <p className="text-xs text-gray-500">Projeto: {item.project}</p>
                        </div>
                        <div className={`text-xs font-medium px-2 py-1 rounded-full ${
                          item.days > 3 ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {item.days} {item.days === 1 ? 'dia' : 'dias'}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Próximos Eventos */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base font-medium">Próximos Eventos</CardTitle>
                <Button variant="ghost" size="sm" className="h-8 text-xs">
                  Calendário
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y">
                  {[
                    { title: 'Reunião com Cliente', time: '10:00 - 11:30', date: 'Hoje' },
                    { title: 'Entrega de Renderização 3D', time: '16:00', date: 'Amanhã' },
                    { title: 'Visita à Obra', time: '09:00 - 12:00', date: '25/05/2025' },
                  ].map((event, index) => (
                    <div key={index} className="px-6 py-3 hover:bg-gray-50">
                      <div className="flex flex-col">
                        <p className="text-sm font-medium">{event.title}</p>
                        <div className="flex justify-between mt-1">
                          <p className="text-xs text-gray-500">{event.time}</p>
                          <p className={`text-xs ${event.date === 'Hoje' ? 'text-accent font-medium' : 'text-gray-500'}`}>{event.date}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
