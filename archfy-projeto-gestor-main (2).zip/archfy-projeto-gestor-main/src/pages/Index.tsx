
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Eye, EyeOff, ArrowRight, Building2, CheckCircle, MessageSquare } from "lucide-react";

const Index = () => {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [carregando, setCarregando] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !senha) {
      toast.error("Por favor, preencha todos os campos");
      return;
    }
    
    setCarregando(true);
    
    // Simulação de login - em produção seria uma chamada real de API
    setTimeout(() => {
      setCarregando(false);
      toast.success("Login realizado com sucesso!");
      navigate("/dashboard");
    }, 1500);
  };

  const toggleLoginForm = () => {
    setShowLogin(!showLogin);
  };

  return (
    <div className="min-h-screen w-full">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-primary rounded-md flex items-center justify-center">
              <span className="text-white font-bold text-xl">A</span>
            </div>
            <h1 className="text-3xl font-bold text-primary">ArchFy</h1>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-700 hover:text-primary font-medium">Home</a>
            <a href="#" className="text-gray-700 hover:text-primary font-medium">Sobre</a>
            <a href="#" className="text-gray-700 hover:text-primary font-medium">Contato</a>
            <Button 
              onClick={toggleLoginForm} 
              variant="outline" 
              className="font-medium"
            >
              {showLogin ? "Voltar" : "Login"}
            </Button>
          </nav>
          <Button 
            onClick={toggleLoginForm}
            variant="outline" 
            className="md:hidden font-medium"
          >
            {showLogin ? "Voltar" : "Login"}
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-6 py-12 md:py-20">
        {showLogin ? (
          <div className="w-full max-w-md mx-auto space-y-8">
            <div className="text-center">
              <h2 className="text-2xl font-semibold text-gray-700 mb-1">Bem-vindo de volta</h2>
              <p className="text-gray-500">Faça login para acessar sua conta</p>
            </div>

            <Card className="card-shadow">
              <CardContent className="pt-6">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-gray-700">E-mail</label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="input-primary"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label htmlFor="senha" className="text-sm font-medium text-gray-700">Senha</label>
                      <a href="#" className="text-xs text-primary hover:underline">Esqueceu a senha?</a>
                    </div>
                    <div className="relative">
                      <Input
                        id="senha"
                        type={mostrarSenha ? "text" : "password"}
                        placeholder="••••••••"
                        value={senha}
                        onChange={(e) => setSenha(e.target.value)}
                        className="input-primary pr-10"
                        required
                      />
                      <button
                        type="button"
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                        onClick={() => setMostrarSenha(!mostrarSenha)}
                      >
                        {mostrarSenha ? (
                          <EyeOff className="h-5 w-5 text-gray-400" />
                        ) : (
                          <Eye className="h-5 w-5 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-accent hover:bg-accent/90 text-primary font-medium flex items-center justify-center gap-2"
                    disabled={carregando}
                  >
                    {carregando ? "Entrando..." : "Entrar"}
                    {!carregando && <ArrowRight className="w-4 h-4" />}
                  </Button>
                </form>

                <div className="mt-6 text-center">
                  <p className="text-sm text-gray-600">
                    Não tem uma conta?{" "}
                    <a href="#" className="text-primary hover:underline font-medium">
                      Cadastre-se
                    </a>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div>
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Tecnologia que transforma o jeito de construir
                </h1>
                <p className="mt-4 text-xl text-gray-600">
                  Sua obra mais organizada, do início ao fim.
                </p>
              </div>
              <Button 
                onClick={toggleLoginForm}
                size="lg" 
                className="bg-accent text-primary hover:bg-accent/90 font-medium text-lg px-8 py-6"
              >
                Comece agora
              </Button>
            </div>
            
            <div className="bg-gray-50 rounded-xl p-6 shadow-lg">
              <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-accent/20 rounded-full flex items-center justify-center">
                      <span className="text-accent font-medium">A</span>
                    </div>
                    <span className="font-medium">Olá, Marcos</span>
                  </div>
                  <div className="w-6 h-6 bg-gray-100 rounded"></div>
                </div>
                
                <div className="border rounded-lg p-4 mb-4">
                  <div className="flex justify-between mb-2">
                    <h3 className="font-semibold">Residencia Alves</h3>
                    <button className="text-gray-400">•••</button>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">Em andamento</p>
                  <div className="w-full h-2 bg-gray-100 rounded-full mb-4">
                    <div className="h-2 bg-accent rounded-full w-1/2"></div>
                  </div>
                  
                  <div className="mb-2">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="font-medium">Frcime: estepas</span>
                      <span className="text-gray-600">4 / 8</span>
                    </div>
                  </div>
                  
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-6 h-6 bg-accent/20 rounded-full flex items-center justify-center">
                        <CheckCircle className="w-4 h-4 text-accent" />
                      </div>
                      <div className="flex justify-between w-full">
                        <span className="text-sm">Fundação</span>
                        <span className="text-xs text-gray-500">Até de abril</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-6 h-6 bg-accent/20 rounded-full flex items-center justify-center">
                        <CheckCircle className="w-4 h-4 text-accent" />
                      </div>
                      <div className="flex justify-between w-full">
                        <span className="text-sm">Estrutura</span>
                        <span className="text-xs text-gray-500">Até 27 de abril</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-6 h-6 bg-accent/20 rounded-full flex items-center justify-center">
                        <CheckCircle className="w-4 h-4 text-accent" />
                      </div>
                      <div className="flex justify-between w-full">
                        <span className="text-sm">Alvenaria</span>
                        <span className="text-xs text-gray-500">Até 6 de maio</span>
                      </div>
                    </div>
                  </div>
                  
                  <Button className="w-full bg-gray-50 text-gray-700 hover:bg-gray-100 font-medium flex items-center justify-center gap-2">
                    Próximas etapas
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="border rounded-lg p-4">
                  <h3 className="font-semibold mb-2">Progresso da Obra</h3>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-xl font-bold">R$ 65.800</span>
                  </div>
                  <div className="w-full h-2 bg-gray-100 rounded-full mb-2">
                    <div className="h-2 bg-accent rounded-full w-3/4"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Features Section */}
      {!showLogin && (
        <section className="bg-gray-50 py-16">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
                <div className="w-12 h-12 bg-gray-100 rounded-lg mb-4 flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Painel do Arquiteto</h3>
                <p className="text-gray-600">
                  Gerencie projetos e tarefas com facilidade
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
                <div className="w-12 h-12 bg-gray-100 rounded-lg mb-4 flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Progresso da Obra</h3>
                <p className="text-gray-600">
                  Compartilhe etapas e prazos com o cliente
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
                <div className="w-12 h-12 bg-gray-100 rounded-lg mb-4 flex items-center justify-center">
                  <MessageSquare className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Chatbot Inteligente</h3>
                <p className="text-gray-600">
                  Responda dúvidas da obra de forma rápida
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-white border-t mt-auto py-8">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
                <span className="text-white font-bold text-sm">A</span>
              </div>
              <h2 className="text-xl font-bold text-primary">ArchFy</h2>
            </div>
            
            <div className="text-center md:text-right text-sm text-gray-500">
              © 2025 ArchFy - Gerenciamento para Arquitetos
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
