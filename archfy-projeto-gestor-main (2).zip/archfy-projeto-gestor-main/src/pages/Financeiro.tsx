
import React, { useState } from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import FluxoCaixa from '@/components/financeiro/FluxoCaixa';
import ContasPagarReceber from '@/components/financeiro/ContasPagarReceber';
import ComissoesProjetos from '@/components/financeiro/ComissoesProjetos';
import OrdemCompra from '@/components/financeiro/OrdemCompra';
import FinanceiroHeader from '@/components/financeiro/FinanceiroHeader';

const Financeiro = () => {
  const [periodo, setPeriodo] = useState('mensal');

  return (
    <Layout>
      <FinanceiroHeader />
      
      <div className="p-4 md:p-6">
        <Tabs defaultValue="fluxo-caixa" className="w-full">
          <TabsList className="mb-6 bg-muted">
            <TabsTrigger value="fluxo-caixa">Fluxo de Caixa</TabsTrigger>
            <TabsTrigger value="contas">Contas a Pagar e Receber</TabsTrigger>
            <TabsTrigger value="comissoes">Comissões de Projetos</TabsTrigger>
            <TabsTrigger value="ordens-compra">Ordens de Compra</TabsTrigger>
          </TabsList>

          <div className="flex items-center justify-end mb-4 space-x-2">
            <button
              onClick={() => setPeriodo('semanal')}
              className={`px-3 py-1 text-sm rounded-md transition-colors ${
                periodo === 'semanal' ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground'
              }`}
            >
              Semana
            </button>
            <button
              onClick={() => setPeriodo('mensal')}
              className={`px-3 py-1 text-sm rounded-md transition-colors ${
                periodo === 'mensal' ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground'
              }`}
            >
              Mês
            </button>
            <button
              onClick={() => setPeriodo('anual')}
              className={`px-3 py-1 text-sm rounded-md transition-colors ${
                periodo === 'anual' ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground'
              }`}
            >
              Ano
            </button>
          </div>

          <TabsContent value="fluxo-caixa" className="mt-0">
            <FluxoCaixa periodo={periodo} />
          </TabsContent>

          <TabsContent value="contas" className="mt-0">
            <ContasPagarReceber periodo={periodo} />
          </TabsContent>

          <TabsContent value="comissoes" className="mt-0">
            <ComissoesProjetos periodo={periodo} />
          </TabsContent>

          <TabsContent value="ordens-compra" className="mt-0">
            <OrdemCompra periodo={periodo} />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Financeiro;
